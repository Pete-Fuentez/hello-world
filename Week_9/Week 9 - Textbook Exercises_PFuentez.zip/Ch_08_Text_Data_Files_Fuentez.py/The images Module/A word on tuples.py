from PIL import Image

image_path = r"C:\Users\fuent\Documents\Script program\archive\weekly\Week_9\Ch_08_Text_Data_Files_Fuentez.py\The images Module\Image\smokey.gif"
image = Image.open(image_path)
image = image.convert("RGB")

(r, g, b) = image.getpixel((0, 0))
print(f"Original RGB values at (0, 0): R={r}, G={g}, B={b}")

r = min(r + 10, 255)
g = min(g + 10, 255)
b = min(b + 10, 255)

image.putpixel((0, 0), (r, g, b))
image.save(r"C:\Users\fuent\Documents\Script program\archive\weekly\Week_9\Ch_08_Text_Data_Files_Fuentez.py\The images Module\Image\smokey_modified.gif")

print(f"New RGB values at (0, 0): R={r}, G={g}, B={b}")

def average(triple):
    (a, b, c) = triple
    return (a + b + c) / 3

print("Average of 3 Numbers:", average((40, 50, 60)))
