import tkinter as tk
from tkinter import messagebox

def calculate_tax():
    try:
        income = float(entry_income.get())
        tax_rate = float(entry_tax_rate.get())
        tax = income * (tax_rate / 100)
        label_result.config(text=f"Calculated Tax: ${tax:.2f}")
    except ValueError:
        messagebox.showerror("Invalid input", "Please enter valid numbers for income and tax rate.")

def clear_fields():
    entry_income.delete(0, tk.END)
    entry_tax_rate.delete(0, tk.END)
    label_result.config(text="Calculated Tax: $0.00")

root = tk.Tk()
root.title("Tax Calculator")

label_income = tk.Label(root, text="Income:")
label_income.grid(row=0, column=0, padx=10, pady=10, sticky="e")

entry_income = tk.Entry(root)
entry_income.grid(row=0, column=1, padx=10, pady=10)

label_tax_rate = tk.Label(root, text="Tax Rate (%):")
label_tax_rate.grid(row=1, column=0, padx=10, pady=10, sticky="e")

entry_tax_rate = tk.Entry(root)
entry_tax_rate.grid(row=1, column=1, padx=10, pady=10)

btn_calculate = tk.Button(root, text="Calculate Tax", command=calculate_tax)
btn_calculate.grid(row=2, column=0, columnspan=2, pady=10)

btn_clear = tk.Button(root, text="Clear", command=clear_fields)
btn_clear.grid(row=3, column=0, columnspan=2, pady=5)

label_result = tk.Label(root, text="Calculated Tax: $0.00")
label_result.grid(row=4, column=0, columnspan=2, pady=10)

root.mainloop()
