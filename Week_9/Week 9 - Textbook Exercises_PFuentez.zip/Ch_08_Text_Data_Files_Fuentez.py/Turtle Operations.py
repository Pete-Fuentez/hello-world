import turtle

def draw_square(t, x, y, length):
    t.up()
    t.goto(x, y)
    t.setheading(270)
    t.down()
    for count in range(4):
        t.forward(length)
        t.left(90)

screen = turtle.Screen()
t = turtle.Turtle()
draw_square(t, 0, 0, 100)
turtle.done()
