import turtle

def drawFractalLine(t, distance, angle, level):
    if level == 0:
        t.forward(distance)
    else:
        distance /= 3.0
        drawFractalLine(t, distance, angle, level - 1)
        t.left(60)
        drawFractalLine(t, distance, angle, level - 1)
        t.right(120)
        drawFractalLine(t, distance, angle, level - 1)
        t.left(60)
        drawFractalLine(t, distance, angle, level - 1)

def drawKochSnowflake(t, distance, level):
    for angle in [0, -120, 120]:
        drawFractalLine(t, distance, angle, level)
        t.right(120)

t = turtle.Turtle()
t.speed(0)
t.penup()
t.goto(-150, 100)
t.pendown()

drawKochSnowflake(t, 300, 3)

t.hideturtle()
turtle.done()
