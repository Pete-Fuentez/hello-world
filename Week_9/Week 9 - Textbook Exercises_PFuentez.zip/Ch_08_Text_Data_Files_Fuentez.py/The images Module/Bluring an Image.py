from PIL import Image
from functools import reduce

image = Image.open(r"C:\Users\fuent\Documents\Script program\archive\weekly\Week_9\Ch_08_Text_Data_Files_Fuentez.py\The images Module\Image\smokey.gif")
image.show()

new_image = image.copy()
new_image.show()

new_image = new_image.convert("L")
new_image.show()

def blur(image):
    width, height = image.size
    new_image = Image.new("RGB", (width, height))

    def triple_sum(triple1, triple2):
        return (triple1[0] + triple2[0], triple1[1] + triple2[1], triple1[2] + triple2[2])

    for y in range(1, height - 1):
        for x in range(1, width - 1):
            old_p = image.getpixel((x, y))
            left = image.getpixel((x - 1, y))
            right = image.getpixel((x + 1, y))
            top = image.getpixel((x, y - 1))
            bottom = image.getpixel((x, y + 1))

            if isinstance(old_p, int):
                sums = reduce(lambda x, y: x + y, [old_p, left, right, top, bottom])
                average = sums // 5
                new_image.putpixel((x, y), (average, average, average))
            else:
                sums = reduce(triple_sum, [old_p, left, right, top, bottom])
                averages = tuple(map(lambda x: x // 5, sums))
                new_image.putpixel((x, y), averages)

    return new_image

blurred_image = blur(image)
blurred_image.show()
