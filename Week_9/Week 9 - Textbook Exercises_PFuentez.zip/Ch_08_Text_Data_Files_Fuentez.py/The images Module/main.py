import theimagesmodule

theimagesmodule.process_smokey_image()  
