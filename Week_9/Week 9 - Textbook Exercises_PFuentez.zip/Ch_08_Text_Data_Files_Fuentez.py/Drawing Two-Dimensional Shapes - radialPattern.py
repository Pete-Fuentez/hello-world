import turtle

def square(t, length):
    for _ in range(4):
        t.forward(length)
        t.left(90)

def hexagon(t, length):
    for _ in range(6):
        t.forward(length)
        t.left(60)

def radial_pattern(t, n, length, shape):
    for count in range(n):
        shape(t, length)
        t.left(360 / n)

t = turtle.Turtle()
radial_pattern(t, n=10, length=50, shape=square)
t.clear()
radial_pattern(t, n=10, length=50, shape=hexagon)

turtle.done()
