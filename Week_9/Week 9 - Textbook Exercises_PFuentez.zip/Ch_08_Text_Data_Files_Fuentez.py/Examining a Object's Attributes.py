import turtle
import random

screen = turtle.Screen()
screen.bgcolor("blue")

walker = turtle.Turtle()
walker.shape("turtle")
walker.speed(1)
walker.pensize(2)
walker.pencolor("red")
def random_walk(steps):
    for _ in range(steps):
        angle = random.randint(0, 180)
        walker.right(angle)
        walker.forward(30)

random_walk(50)
walker.hideturtle()
turtle.done()
