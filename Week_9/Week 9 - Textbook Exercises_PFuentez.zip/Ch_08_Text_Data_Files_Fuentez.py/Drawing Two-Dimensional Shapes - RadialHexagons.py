def radial_hexagons(t, n, length):
    """Draws a radial pattern of n hexagons with the given length."""
    for count in range(n):
        hexagon(t, length)
        t.left(360 / n)

def hexagon(t, length):
    for _ in range(6):
        t.forward(length)
        t.left(60)

import turtle

screen = turtle.Screen()
t = turtle.Turtle()
radial_hexagons(t, 6, 50)
turtle.done()
