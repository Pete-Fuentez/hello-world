from PIL import Image

def grayscale(image):
    for x in range(image.width):
        for y in range(image.height):
            r, g, b = image.getpixel((x, y))
            gray = int(0.3 * r + 0.59 * g + 0.11 * b)
            image.putpixel((x, y), (gray, gray, gray))
    return image

def sepia(image):
    if image.mode != "RGB":
        image = image.convert("RGB")
        
    grayscale(image)
    
    for x in range(image.width):
        for y in range(image.height):
            r, g, b = image.getpixel((x, y))
            if r < 63:
                r = int(r * 1.1)
                b = int(b * 0.9)
            elif r < 192:
                r = int(r * 1.15)
                b = int(b * 0.85)
            else:
                r = min(int(r * 1.08), 255)
                b = int(b * 0.93)
            image.putpixel((x, y), (r, g, b))
    return image

if __name__ == "__main__":
    img = Image.open(r"C:\Users\fuent\Documents\Script program\weekly\Week_9\Ch_08_Data_Files_ITD2313_PFuentez\smokey.gif").convert("RGB")
    sepia_img = sepia(img)
    sepia_img.show()
    sepia_img.save("sepia_smokey.gif")
