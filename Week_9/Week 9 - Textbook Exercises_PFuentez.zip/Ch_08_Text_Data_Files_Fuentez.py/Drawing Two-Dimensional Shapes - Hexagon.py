import turtle

screen = turtle.Screen()
my_turtle = turtle.Turtle()

def hexagon(t, length):
    for count in range(6):
        t.forward(length)
        t.left(60)

hexagon(my_turtle, 100)

turtle.done()
