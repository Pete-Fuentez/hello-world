from PIL import Image

image = Image.open(r"C:\Users\fuent\Documents\Script program\archive\weekly\Week_9\Ch_08_Text_Data_Files_Fuentez.py\The images Module\Image\smokey.gif")
image.show()

new_image = image.copy()
new_image.show()

new_image = new_image.convert("L")
new_image.show()

def shrink(image, factor):
    width, height = image.size
    new_width = width // factor
    new_height = height // factor
    new_image = Image.new("L", (new_width, new_height))

    old_y = 0
    new_y = 0
    
    while old_y < height - factor:
        old_x = 0
        new_x = 0
        
        while old_x < width - factor:
            old_p = image.getpixel((old_x, old_y))
            new_image.putpixel((new_x, new_y), old_p)
            old_x += factor
            new_x += 1
            
        old_y += factor
        new_y += 1
        
    return new_image

shrunken_image = shrink(image, 2)
shrunken_image.show()
