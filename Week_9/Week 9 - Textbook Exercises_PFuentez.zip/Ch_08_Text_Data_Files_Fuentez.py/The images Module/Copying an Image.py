from PIL import Image

image = Image.open(r"C:\Users\fuent\Documents\Script program\archive\weekly\Week_9\Ch_08_Text_Data_Files_Fuentez.py\The images Module\Image\smokey.gif")
image.show()

new_image = image.copy()
new_image.show()

new_image = new_image.convert("L")
new_image.show()

image.show()
