from images import Image
image = Image("smokey.gif")

width = image.width
print(width) 
height = image.height
print(height)  

# Print the image information
print(f"File name: {image.filename.split('/')[-1]}")
print(f"Width: {image.width}")
print(f"Height: {image.height}")

image.getPixel(0,0)
(294,321,214)

image.draw()

from PIL import Image

# Create a new image with width 150 and height 150
image = Image.new('RGB', (150, 150))

# Create the 'draw' object
draw = ImageDraw.Draw(image)

# Define the blue color
blue = (0, 0, 255)

# Get the y coordinate for the center of the image
y = image.height // 2

# Draw a horizontal blue line in the center of the image
for x in range(image.width):
    image.putpixel((x, y - 1), blue)
    image.putpixel((x, y), blue)
    image.putpixel((x, y + 1), blue)

# Save the image
image.save('blue_line_image.png')





              
