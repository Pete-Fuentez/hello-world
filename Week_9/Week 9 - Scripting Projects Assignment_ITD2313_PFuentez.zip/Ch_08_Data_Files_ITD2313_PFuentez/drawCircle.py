import turtle
import math

def drawCircle(t, x, y, radius):
    t.penup()
    t.goto(x, y - radius)
    t.pendown()
    distance = 2.0 * math.pi * radius / 120.0
    for _ in range(120):
        t.forward(distance)
        t.left(3)

if __name__ == "__main__":
    screen = turtle.Screen()
    t = turtle.Turtle()
    drawCircle(t, 0, 0, 50)
    screen.mainloop()
