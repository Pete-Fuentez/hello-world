from PIL import Image

def process_smokey_image(image_path, save_path):
    try:
        img = Image.open(image_path)
        img.show()
        img.save(save_path)

        image_info = {
            "file name": img.filename.split('\\')[-1],
            "width": img.width,
            "height": img.height
        }

        print("file name:", image_info["file name"])
        print("width:", image_info["width"])
        print("height:", image_info["height"])
        
        pixel_value = img.getpixel((0, 0))
        print("pixel at (0, 0):", pixel_value)

        img = img.resize((150, 150))
        blue = (0, 0, 255)
        y = img.height // 2

        for x in range(img.width):
            img.putpixel((x, y - 1), blue)
            img.putpixel((x, y), blue)
            img.putpixel((x, y + 1), blue)

        img.show()

    except FileNotFoundError:
        print("Image file not found. Please check the path.")
    except IOError:
        print("Unable to open or save the image file.")
    except Exception as e:
        print(f"An error occurred: {e}")

image_path = r"C:\Users\fuent\Documents\Script program\archive\weekly\Week_9\Ch_08_Text_Data_Files_Fuentez.py\The images Module\Image\smokey.gif"
save_path = r"C:\Users\fuent\Documents\Script program\archive\weekly\Week_9\Ch_08_Text_Data_Files_Fuentez.py\The images Module\Image\smokey_copy.gif"

process_smokey_image(image_path, save_path)
