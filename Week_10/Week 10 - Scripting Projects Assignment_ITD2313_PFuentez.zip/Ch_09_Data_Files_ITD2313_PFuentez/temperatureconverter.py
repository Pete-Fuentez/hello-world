import tkinter as tk
from tkinter import messagebox

def fahrenheit_to_celsius():
    try:
        fahrenheit = float(entry_fahrenheit.get())
        celsius = (fahrenheit - 32) * 5 / 9
        entry_celsius.delete(0, tk.END)
        entry_celsius.insert(0, f"{celsius:.2f}")
    except ValueError:
        messagebox.showerror("Invalid input", "Please enter a valid number for Fahrenheit.")

def celsius_to_fahrenheit():
    try:
        celsius = float(entry_celsius.get())
        fahrenheit = celsius * 9 / 5 + 32
        entry_fahrenheit.delete(0, tk.END)
        entry_fahrenheit.insert(0, f"{fahrenheit:.2f}")
    except ValueError:
        messagebox.showerror("Invalid input", "Please enter a valid number for Celsius.")

root = tk.Tk()
root.title("Temperature Converter")

label_fahrenheit = tk.Label(root, text="Fahrenheit:")
label_fahrenheit.grid(row=0, column=0, padx=10, pady=10)

label_celsius = tk.Label(root, text="Celsius:")
label_celsius.grid(row=0, column=1, padx=10, pady=10)

entry_fahrenheit = tk.Entry(root)
entry_fahrenheit.grid(row=1, column=0, padx=10, pady=10)
entry_fahrenheit.insert(0, "32.0")

entry_celsius = tk.Entry(root)
entry_celsius.grid(row=1, column=1, padx=10, pady=10)
entry_celsius.insert(0, "0.0")

btn_f_to_c = tk.Button(root, text=">>>>", command=fahrenheit_to_celsius)
btn_f_to_c.grid(row=2, column=0, padx=10, pady=10)

btn_c_to_f = tk.Button(root, text="<<<<", command=celsius_to_fahrenheit)
btn_c_to_f.grid(row=2, column=1, padx=10, pady=10)

root.mainloop()
