def square(t, length):
   
    for count in range(4):
        t.forward(length)
        t.left(90)

import turtle
screen = turtle.Screen()
my_turtle = turtle.Turtle()
square(my_turtle, 100)
turtle.done()

